"""
Core transform steps: load the FOCUS CSV, clean the BillingAccountId field,
convert to Parquet. Pure functions, no I/O to Azure - easy to unit test.
"""

from __future__ import annotations

import gzip
import io
import logging
import re

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

logger = logging.getLogger(__name__)

# Matches the ARM resource-id style prefix Azure puts on BillingAccountId,
# e.g. "/providers/Microsoft.Billing/billingAccounts/123456" -> "123456"
_BILLING_ACCOUNT_PREFIX_RE = re.compile(r"^/providers/Microsoft\.Billing/billingAccounts/")

# Gzip files always start with this two-byte magic number, regardless of
# file extension - Azure's native Cost Management Export delivers .csv.gz
# by default, so this check matters even if a filename says ".csv".
_GZIP_MAGIC = b"\x1f\x8b"


def _maybe_decompress(raw_bytes: bytes) -> bytes:
    if raw_bytes[:2] == _GZIP_MAGIC:
        logger.info("Input is gzip-compressed - decompressing before parsing")
        return gzip.decompress(raw_bytes)
    return raw_bytes


def load_focus_csv(csv_bytes: bytes) -> pd.DataFrame:
    """Parses the raw FOCUS export bytes into a DataFrame. Transparently
    handles gzip-compressed input (detected by magic number, not filename)
    since Azure's native Cost Management Export delivers .csv.gz by default."""
    csv_bytes = _maybe_decompress(csv_bytes)
    df = pd.read_csv(io.BytesIO(csv_bytes))
    logger.info("Loaded FOCUS CSV: %d rows, %d columns", len(df), len(df.columns))
    return df


def clean_billing_account_id(df: pd.DataFrame) -> pd.DataFrame:
    """Strips the ARM resource-id prefix from BillingAccountId, leaving just
    the account id itself. No-op (with a warning) if the column is absent."""
    if "BillingAccountId" not in df.columns:
        logger.warning("BillingAccountId column not found - skipping cleanup step")
        return df

    before_sample = df["BillingAccountId"].iloc[0] if len(df) else None
    df = df.copy()
    df["BillingAccountId"] = (
        df["BillingAccountId"]
        .astype(str)
        .str.replace(_BILLING_ACCOUNT_PREFIX_RE, "", regex=True)
    )
    after_sample = df["BillingAccountId"].iloc[0] if len(df) else None
    logger.info("Cleaned BillingAccountId (e.g. %r -> %r)", before_sample, after_sample)
    return df


def csv_to_parquet(df: pd.DataFrame, compression: str = "snappy") -> bytes:
    """Converts a DataFrame to Parquet bytes, ready to upload. Compression
    defaults to snappy, matching the ".snappy.parquet" naming convention
    in Cloudability's sample manifest/report keys."""
    table = pa.Table.from_pandas(df, preserve_index=False)
    buf = io.BytesIO()
    pq.write_table(table, buf, compression=compression)
    parquet_bytes = buf.getvalue()
    logger.info("Converted to Parquet (%s): %d bytes", compression, len(parquet_bytes))
    return parquet_bytes
