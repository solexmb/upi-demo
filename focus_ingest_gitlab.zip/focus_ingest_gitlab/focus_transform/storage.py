"""
Azure Blob Storage I/O. Uses DefaultAzureCredential throughout, so the same
code authenticates via Managed Identity in Azure and via `az login` /
environment credentials when run locally - no storage keys in code or config.
"""

from __future__ import annotations

import json
import logging

from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient

logger = logging.getLogger(__name__)


def download_blob(account_url: str, container: str, blob_name: str) -> bytes:
    """Fetches a single blob's bytes. Used for local/manual testing against
    the real source container - the Function App gets its bytes directly
    from the blob trigger instead."""
    credential = DefaultAzureCredential()
    service_client = BlobServiceClient(account_url=account_url, credential=credential)
    blob_client = service_client.get_container_client(container).get_blob_client(blob_name)
    data = blob_client.download_blob().readall()
    logger.info("Downloaded %s/%s (%d bytes)", container, blob_name, len(data))
    return data


def get_latest_blob_name(
    account_url: str,
    container: str,
    prefix: str = "",
    suffixes: tuple[str, ...] = (".csv", ".csv.gz"),
) -> str:
    """Finds the most-recently-modified blob under `prefix` whose name ends
    in one of `suffixes`. Used by the unattended daily pipeline (GitLab CI,
    etc.) to find the newest Cost Management Export file automatically,
    since there's no blob trigger to hand it a specific file by name."""
    credential = DefaultAzureCredential()
    service_client = BlobServiceClient(account_url=account_url, credential=credential)
    container_client = service_client.get_container_client(container)

    candidates = [
        blob for blob in container_client.list_blobs(name_starts_with=prefix)
        if blob.name.lower().endswith(suffixes)
    ]
    if not candidates:
        raise FileNotFoundError(
            f"No blobs matching {suffixes} found under prefix {prefix!r} "
            f"in container {container!r}"
        )

    latest = max(candidates, key=lambda b: b.last_modified)
    logger.info(
        "Found %d matching blob(s); latest is %s (modified %s)",
        len(candidates), latest.name, latest.last_modified,
    )
    return latest.name


def upload_outputs(
    account_url: str,
    container: str,
    parquet_bytes: bytes,
    manifest: dict,
    paths: dict,
) -> None:
    """Uploads the Parquet data file and the manifest.json to the
    destination container, at the paths computed by build_manifest()."""
    credential = DefaultAzureCredential()
    service_client = BlobServiceClient(account_url=account_url, credential=credential)
    container_client = service_client.get_container_client(container)

    parquet_path = f"{paths['base_path']}/{paths['parquet_filename']}"
    manifest_path = f"{paths['base_path']}/{paths['manifest_filename']}"

    container_client.upload_blob(name=parquet_path, data=parquet_bytes, overwrite=True)
    container_client.upload_blob(
        name=manifest_path,
        data=json.dumps(manifest, indent=2),
        overwrite=True,
    )
    logger.info("Uploaded data file: %s/%s", container, parquet_path)
    logger.info("Uploaded manifest: %s/%s", container, manifest_path)
