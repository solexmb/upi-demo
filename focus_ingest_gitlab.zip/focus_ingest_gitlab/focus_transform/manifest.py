"""
Builds the manifest.json and destination path Cloudability's custom-data
(FOCUS) ingress expects. Path structure and manifest fields confirmed
against IBM's documentation and sample manifest:

    <Root Directory>/<Optional_Sub_Directories>/<Vendor>/<Report_Period>/<Epoch Time Folder>/<prefix>-Manifest.json

Sample manifest (from IBM's docs):
    {
      "compression": "GZIP",
      "content_type": "Parquet",
      "report_id": "uuid-f431e214843b3c19756368",
      "root_dir": "byod-input-prod",
      "all_report_keys": [
        "<complete/path/excluding/root_dir>/cost-and-usage-report-00001.snappy.parquet",
        "<complete/path/excluding/root_dir>/cost-and-usage-report-00002.snappy.parquet"
      ],
      "updated_at": "2024-04-04T05:00:22Z",
      "focus_version": "1.0"
    }

Key rules confirmed from the docs:
- Report Period is always YYYYMMDD-YYYYMMDD spanning a full calendar month:
  first day of the month to first day of the FOLLOWING month (not the
  actual max date in the data). E.g. report period 2023-02 -> 20230201-20230301.
- The "M" in "Manifest.json" is always capitalized.
- root_dir is the Root Directory itself (your Azure container name) -
  all_report_keys paths are relative to that, i.e. they do NOT repeat root_dir.
- Every upload must contain the full month-to-date dataset, not a daily delta.

compression: IBM's sample shows "GZIP" next to filenames ending in
".snappy.parquet", which is inconsistent in the sample itself. This code
sets `compression` to reflect whatever codec the Parquet file is actually
written with (see transform.py - defaults to "snappy") rather than copying
the sample verbatim, since the field should describe the real file.
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone

import pandas as pd

logger = logging.getLogger(__name__)


def _first_of_next_month(year: int, month: int) -> tuple[int, int]:
    if month == 12:
        return year + 1, 1
    return year, month + 1


def derive_report_period(df: pd.DataFrame) -> str:
    """Returns YYYYMMDD-YYYYMMDD spanning the full calendar month the data
    belongs to: first day of the month to first day of the NEXT month.
    Per IBM's spec, this is a fixed calendar boundary, not the actual min/max
    date found in the data."""
    if "ChargePeriodStart" in df.columns and len(df):
        reference_date = pd.to_datetime(df["ChargePeriodStart"]).min()
    else:
        logger.warning(
            "ChargePeriodStart not found or data empty - using today's date "
            "to determine the reporting month."
        )
        reference_date = datetime.now(timezone.utc)

    year, month = reference_date.year, reference_date.month
    start = datetime(year, month, 1)
    next_year, next_month = _first_of_next_month(year, month)
    end = datetime(next_year, next_month, 1)

    report_period = f"{start.strftime('%Y%m%d')}-{end.strftime('%Y%m%d')}"
    logger.info("Derived report period: %s", report_period)
    return report_period


def build_manifest(
    report_period: str,
    vendor: str,
    root_dir: str,
    optional_sub_directories: str = "",
    report_prefix: str = "cost-and-usage-report",
    focus_version: str = "1.0",
    parquet_compression: str = "snappy",
) -> tuple[dict, dict]:
    """Returns (paths, manifest_dict).

    paths contains the base_path (the epoch-time folder, relative to the
    container root) plus the filenames for the Parquet data file and the
    manifest file itself.
    """
    epoch = int(datetime.now(timezone.utc).timestamp())

    segments = [optional_sub_directories, vendor, report_period, str(epoch)]
    base_path = "/".join(s for s in segments if s)

    parquet_filename = f"{report_prefix}-00001.snappy.parquet"
    manifest_filename = f"{report_prefix}-Manifest.json"  # capital "M" per spec

    data_file_key = f"{base_path}/{parquet_filename}"

    manifest = {
        "compression": parquet_compression.upper(),
        "content_type": "Parquet",
        "report_id": f"uuid-{uuid.uuid4().hex}",
        "root_dir": root_dir,
        "all_report_keys": [data_file_key],
        "updated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "focus_version": focus_version,
    }

    paths = {
        "base_path": base_path,
        "parquet_filename": parquet_filename,
        "manifest_filename": manifest_filename,
    }

    logger.info("Built manifest for path: %s", base_path)
    return paths, manifest
