# FOCUS Ingest Pipeline (GitLab CI)

Automates the previously-manual process: downloading the Azure Cost
Management Export, transforming it to FOCUS-compliant Parquet, and
uploading it (with a manifest.json) to the storage container Cloudability
reads from. Runs as a scheduled GitLab CI pipeline, or on demand.

## Structure

```
focus_ingest_gitlab/
  focus_transform/
    config.py          # settings, loaded from environment variables
    schema.py           # FOCUS column validation (logs warnings, non-fatal)
    transform.py          # load CSV (handles gzip automatically), clean
                            # BillingAccountId, convert to Parquet (snappy)
    manifest.py              # report-period (calendar month) + manifest.json
    storage.py                 # blob download/upload + finding the latest export
    pipeline.py                  # unattended entry point - used by GitLab CI
    cli.py                        # interactive entry point - for local testing
    __init__.py
  tests/
    test_transform.py    # unit tests, no Azure connection required
  .gitlab-ci.yml        # the scheduled pipeline definition
  requirements.txt
  sample_focus_export.csv  # fixture for local dry runs
```

`pipeline.py` is what actually runs in CI: it finds the most-recently
modified export file in the source container, downloads it, transforms it,
and uploads the result - no file path needs to be given, since there's no
human there to provide one. `cli.py` is for your own local testing against
a specific file, and isn't used by the CI job at all.

## One-time setup

### 1. Service principal / credentials

GitLab CI needs an identity to authenticate to Azure with. Create (or
reuse) a service principal (**Microsoft Entra ID > App registrations**)
with a client secret, and grant it:
- `Storage Blob Data Reader` on the **source** storage account (where the
  Cost Management Export lands)
- `Storage Blob Data Contributor` on the **destination** storage account
  (the one Cloudability reads from)

### 2. GitLab CI/CD variables

Project **Settings > CI/CD > Variables**, each marked **Protected** and
**Masked**:

| Variable | Value |
|---|---|
| `AZURE_CLIENT_ID` | Service principal's Application (client) ID |
| `AZURE_TENANT_ID` | Your Azure AD tenant ID |
| `AZURE_CLIENT_SECRET` | The client secret generated above |
| `SOURCE_ACCOUNT_URL` | `https://<source-account>.blob.core.windows.net` |
| `SOURCE_CONTAINER` | Container the Cost Management Export writes to |
| `FOCUS_DEST_ACCOUNT_URL` | `https://<destination-account>.blob.core.windows.net` |
| `FOCUS_DEST_CONTAINER` | Your Cloudability "Root Directory" container name |
| `FOCUS_VENDOR` | Must match Cloudability's credential config exactly (e.g. `Microsoft Azure`) |
| `FOCUS_REPORT_PREFIX` | Must match Cloudability's "Manifest Prefix" field exactly (e.g. `reports`) |

Optional: `SOURCE_PREFIX`, `FOCUS_SUB_DIRECTORIES`, `FOCUS_SPEC_VERSION` -
only needed if your setup uses them.

The three `AZURE_*` variables are picked up automatically by
`DefaultAzureCredential` (used throughout `focus_transform/storage.py`) -
no code changes needed to authenticate.

### 3. Create the daily schedule

Project **Build > Pipeline schedules > New schedule**. Use cron syntax
(e.g. `0 6 * * *` for 6am daily), set your timezone, and target the branch
this code lives on.

## Running it

**On its schedule** - no action needed once set up above.

**Manually, any time**, two ways:

1. **GitLab UI:** Project > Build > Pipelines > **Run pipeline**, pick the
   branch, run. (Works because the job's `rules` in `.gitlab-ci.yml` allow
   `$CI_PIPELINE_SOURCE == "web"`, which is what a UI-triggered run reports.)
2. **API / trigger token** (Project > Settings > CI/CD > Pipeline trigger
   tokens > create one):
   ```bash
   curl -X POST \
     -F token=<your-trigger-token> \
     -F ref=main \
     https://gitlab.example.com/api/v4/projects/<project-id>/trigger/pipeline
   ```

Both manual options run the exact same `focus_ingest_daily` job the
schedule runs - there's no separate "manual mode." Note that triggering a
run close to the scheduled time just means two runs land in two different
epoch-time folders in the destination container - not an overwrite, but
worth being aware of if you're testing repeatedly.

## Local testing (before relying on this in CI)

```bash
pip install -r requirements.txt --break-system-packages
pytest tests/

# Dry run against the sample file - writes Parquet + manifest to disk, no upload
python -m focus_transform.cli --input sample_focus_export.csv --output-dir ./out

# Dry run against a real export you've downloaded yourself
python -m focus_transform.cli --input your_export.csv.gz --output-dir ./out
```

To test the actual unattended pipeline logic locally (fetching from the
source container automatically, same as CI would), set the environment
variables listed above and run:

```bash
export AZURE_CLIENT_ID=... AZURE_TENANT_ID=... AZURE_CLIENT_SECRET=...
export SOURCE_ACCOUNT_URL=... SOURCE_CONTAINER=...
export FOCUS_DEST_ACCOUNT_URL=... FOCUS_DEST_CONTAINER=...
python -m focus_transform.pipeline
```

## Known open items

- **Manifest field confirmation:** the `compression` field in IBM's sample
  manifest shows `"GZIP"` next to a `.snappy.parquet` filename, which is
  internally inconsistent. This code reports the actual Parquet codec used
  (`SNAPPY`) rather than copying the sample literally - worth confirming
  with IBM/Cloudability support which one their ingestion actually expects.
- **Historical/backfill months:** this pipeline only processes whatever's
  newest in the source container at run time - any past months need a
  deliberate backfill (historical export pulled separately, run through
  `cli.py`, uploaded to their own correctly-dated folder).
