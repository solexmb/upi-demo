"""
Unit tests for the pure-logic parts of focus_transform - no Azure
connection or credentials required. Run with:

    pip install -r requirements.txt --break-system-packages
    pip install pytest --break-system-packages
    pytest tests/
"""

import pandas as pd
import pytest

from focus_transform.manifest import build_manifest, derive_report_period
from focus_transform.schema import validate_focus_columns
from focus_transform.transform import clean_billing_account_id, csv_to_parquet, load_focus_csv


def _sample_df() -> pd.DataFrame:
    return pd.DataFrame({
        "BillingAccountId": [
            "/providers/Microsoft.Billing/billingAccounts/123456",
            "/providers/Microsoft.Billing/billingAccounts/123456",
        ],
        "ChargePeriodStart": ["2026-09-01T00:00:00Z", "2026-09-05T00:00:00Z"],
        "ChargePeriodEnd": ["2026-09-01T23:59:59Z", "2026-09-05T23:59:59Z"],
        "BilledCost": [10.50, 22.10],
        "ServiceName": ["Storage", "Compute"],
    })


class TestLoadFocusCsv:
    def test_reads_plain_csv(self):
        raw = b"BillingAccountId,BilledCost\n123456,10.50\n"
        df = load_focus_csv(raw)
        assert list(df.columns) == ["BillingAccountId", "BilledCost"]
        assert df.iloc[0]["BilledCost"] == 10.50

    def test_reads_gzip_compressed_csv(self):
        import gzip

        raw = b"BillingAccountId,BilledCost\n123456,10.50\n"
        compressed = gzip.compress(raw)
        df = load_focus_csv(compressed)
        assert list(df.columns) == ["BillingAccountId", "BilledCost"]
        assert df.iloc[0]["BilledCost"] == 10.50


class TestCleanBillingAccountId:
    def test_strips_arm_prefix(self):
        df = clean_billing_account_id(_sample_df())
        assert (df["BillingAccountId"] == "123456").all()

    def test_missing_column_is_noop(self):
        df = pd.DataFrame({"OtherColumn": [1, 2]})
        result = clean_billing_account_id(df)
        assert list(result.columns) == ["OtherColumn"]

    def test_does_not_mutate_input(self):
        original = _sample_df()
        original_copy = original.copy()
        clean_billing_account_id(original)
        pd.testing.assert_frame_equal(original, original_copy)


class TestCsvToParquet:
    def test_produces_nonempty_bytes(self):
        result = csv_to_parquet(_sample_df())
        assert isinstance(result, bytes)
        assert len(result) > 0

    def test_roundtrips_via_pyarrow(self):
        import io
        import pyarrow.parquet as pq

        df = _sample_df()
        parquet_bytes = csv_to_parquet(df)
        table = pq.read_table(io.BytesIO(parquet_bytes))
        assert table.num_rows == len(df)
        assert set(table.column_names) == set(df.columns)


class TestValidateFocusColumns:
    def test_no_missing_columns_when_all_present(self):
        df = pd.DataFrame(columns=[
            "BilledCost", "EffectiveCost", "ContractedCost", "ListCost",
            "BillingAccountId", "BillingCurrency", "ChargeCategory",
            "ChargePeriodStart", "ChargePeriodEnd", "ProviderName",
            "ServiceName", "ServiceCategory",
        ])
        assert validate_focus_columns(df) == []

    def test_reports_missing_columns(self):
        df = pd.DataFrame({"BillingAccountId": ["123"]})
        missing = validate_focus_columns(df)
        assert "BilledCost" in missing
        assert "BillingAccountId" not in missing


class TestReportPeriod:
    def test_derives_from_charge_period_columns(self):
        report_period = derive_report_period(_sample_df())
        assert report_period == "20260901-20260905"

    def test_falls_back_when_columns_missing(self):
        df = pd.DataFrame({"SomeColumn": [1]})
        report_period = derive_report_period(df)
        # Format check only - the fallback is "today", which is not fixed
        start, end = report_period.split("-")
        assert len(start) == 8 and len(end) == 8


class TestBuildManifest:
    def test_manifest_has_expected_fields(self):
        paths, manifest = build_manifest("20260901-20260905", vendor="Azure")
        assert manifest["vendor"] == "Azure"
        assert manifest["reportPeriod"] == "20260901-20260905"
        assert paths["manifest_filename"].endswith("_Manifest.json")
        assert paths["parquet_filename"].endswith(".parquet")

    def test_base_path_includes_optional_sub_directories(self):
        paths, _ = build_manifest(
            "20260901-20260905", vendor="Azure", optional_sub_directories="finance/costs"
        )
        assert paths["base_path"].startswith("finance/costs/Azure/")

    def test_base_path_skips_empty_sub_directories(self):
        paths, _ = build_manifest("20260901-20260905", vendor="Azure")
        assert paths["base_path"].startswith("Azure/")
