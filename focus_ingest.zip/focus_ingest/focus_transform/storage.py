"""
Azure Blob Storage I/O. Uses DefaultAzureCredential throughout, so the same
code authenticates via Managed Identity in Azure and via `az login` /
environment credentials when run locally - no storage keys in code or config.
"""

from __future__ import annotations

import json
import logging

from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient

logger = logging.getLogger(__name__)


def download_blob(account_url: str, container: str, blob_name: str) -> bytes:
    """Fetches a single blob's bytes. Used for local/manual testing against
    the real source container - the Function App gets its bytes directly
    from the blob trigger instead."""
    credential = DefaultAzureCredential()
    service_client = BlobServiceClient(account_url=account_url, credential=credential)
    blob_client = service_client.get_container_client(container).get_blob_client(blob_name)
    data = blob_client.download_blob().readall()
    logger.info("Downloaded %s/%s (%d bytes)", container, blob_name, len(data))
    return data


def upload_outputs(
    account_url: str,
    container: str,
    parquet_bytes: bytes,
    manifest: dict,
    paths: dict,
) -> None:
    """Uploads the Parquet data file and the manifest.json to the
    destination container, at the paths computed by build_manifest()."""
    credential = DefaultAzureCredential()
    service_client = BlobServiceClient(account_url=account_url, credential=credential)
    container_client = service_client.get_container_client(container)

    parquet_path = f"{paths['base_path']}/{paths['parquet_filename']}"
    manifest_path = f"{paths['base_path']}/{paths['manifest_filename']}"

    container_client.upload_blob(name=parquet_path, data=parquet_bytes, overwrite=True)
    container_client.upload_blob(
        name=manifest_path,
        data=json.dumps(manifest, indent=2),
        overwrite=True,
    )
    logger.info("Uploaded data file: %s/%s", container, parquet_path)
    logger.info("Uploaded manifest: %s/%s", container, manifest_path)
