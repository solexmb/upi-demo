"""
Centralized configuration. Reads from environment variables so the same
code runs unchanged locally, in a Function App, or in any other runner -
only the App Settings / .env values change between environments.
"""

from __future__ import annotations

import os
from dataclasses import dataclass


class ConfigError(RuntimeError):
    """Raised when a required setting is missing."""


def _require(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        raise ConfigError(
            f"Missing required setting: {name}. Set it as an environment "
            f"variable locally, or as a Function App Application Setting in Azure."
        )
    return value


@dataclass(frozen=True)
class Settings:
    dest_account_url: str
    dest_container: str
    vendor: str
    optional_sub_directories: str

    @classmethod
    def from_env(cls) -> "Settings":
        return cls(
            dest_account_url=_require("FOCUS_DEST_ACCOUNT_URL"),
            dest_container=_require("FOCUS_DEST_CONTAINER"),
            vendor=os.environ.get("FOCUS_VENDOR", "Azure"),
            optional_sub_directories=os.environ.get("FOCUS_SUB_DIRECTORIES", ""),
        )
