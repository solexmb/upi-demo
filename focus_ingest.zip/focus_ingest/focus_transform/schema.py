"""
Lightweight validation against the FOCUS (FinOps Open Cost and Usage
Specification) column set.

This is intentionally NOT a full conformance validator - FOCUS has ~50
columns with Mandatory/Conditional/Recommended/Optional levels that vary
slightly by spec version (1.0, 1.1, 1.2...), and Microsoft's own Cost
Management FOCUS export doesn't claim 100% conformance either. Hardcoding
the entire spec here would create false failures if the export's column
set doesn't match exactly.

Instead, this checks a small set of core columns that are Mandatory across
FOCUS versions and that the rest of this pipeline actually depends on
(BillingAccountId for the cleanup step, ChargePeriodStart/End for the
report period). Missing columns are logged as warnings, not hard failures,
so a minor schema drift doesn't silently break the whole pipeline - but you
will see it in the logs.

Before relying on this in production, compare CORE_FOCUS_COLUMNS against
the actual column headers your Cost Management Export produces (they're
visible in the CSV itself) and adjust as needed.
"""

from __future__ import annotations

import logging

import pandas as pd

logger = logging.getLogger(__name__)

CORE_FOCUS_COLUMNS = [
    "BilledCost",
    "EffectiveCost",
    "ContractedCost",
    "ListCost",
    "BillingAccountId",
    "BillingCurrency",
    "ChargeCategory",
    "ChargePeriodStart",
    "ChargePeriodEnd",
    "ProviderName",
    "ServiceName",
    "ServiceCategory",
]


def validate_focus_columns(df: pd.DataFrame) -> list[str]:
    """Returns the list of expected core columns that are missing from df.
    Logs a warning for each. Does not raise - the caller decides whether
    missing columns should be fatal for their use case."""
    missing = [col for col in CORE_FOCUS_COLUMNS if col not in df.columns]
    if missing:
        logger.warning(
            "FOCUS file is missing %d expected core column(s): %s. "
            "This may just mean the export uses a different FOCUS spec "
            "version - verify before treating this as an error.",
            len(missing),
            ", ".join(missing),
        )
    else:
        logger.info("All core FOCUS columns present (%d checked).", len(CORE_FOCUS_COLUMNS))
    return missing
