"""
Builds the manifest.json and destination path Cloudability's custom-data
(FOCUS) ingress expects:

    <Root Directory>/<Optional_Sub_Directories>/<Vendor>/<Report_Period>/<Epoch Time>/...

Report Period must be YYYYMMDD-YYYYMMDD, and per Cloudability's docs each
upload must contain the FULL month-to-date dataset (not a daily delta).

IMPORTANT: the exact manifest JSON field names below are a best-effort
reconstruction from the folder-naming spec, not a confirmed schema pulled
from Cloudability's full documentation. Before relying on this in
production, verify the field names against a sample manifest from IBM
support or Cloudability's docs and adjust `build_manifest()` accordingly.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone

import pandas as pd

logger = logging.getLogger(__name__)


def derive_report_period(df: pd.DataFrame) -> str:
    """Returns YYYYMMDD-YYYYMMDD spanning the full month-to-date range in
    the data. Falls back to "start of this month -> today" if the expected
    date columns aren't present."""
    if {"ChargePeriodStart", "ChargePeriodEnd"}.issubset(df.columns):
        start = pd.to_datetime(df["ChargePeriodStart"]).min()
        end = pd.to_datetime(df["ChargePeriodEnd"]).max()
    else:
        logger.warning(
            "ChargePeriodStart/End not found - falling back to calendar "
            "month-to-date for the report period."
        )
        today = datetime.now(timezone.utc)
        start = today.replace(day=1)
        end = today

    report_period = f"{start.strftime('%Y%m%d')}-{end.strftime('%Y%m%d')}"
    logger.info("Derived report period: %s", report_period)
    return report_period


def build_manifest(
    report_period: str,
    vendor: str,
    optional_sub_directories: str = "",
) -> tuple[dict, dict]:
    """Returns (paths, manifest_dict).

    paths contains the base_path plus the filenames to use for the Parquet
    data file and the manifest file itself (capital "M" in "Manifest" per
    Cloudability's naming convention).
    """
    epoch = int(datetime.now(timezone.utc).timestamp())

    segments = [optional_sub_directories, vendor, report_period, str(epoch)]
    base_path = "/".join(s for s in segments if s)

    parquet_filename = f"{epoch}_focus_data.parquet"
    manifest_filename = f"{epoch}_Manifest.json"

    manifest = {
        "manifestVersion": "1.0",
        "vendor": vendor,
        "reportPeriod": report_period,
        "dataFiles": [f"{base_path}/{parquet_filename}"],
        "generatedAt": datetime.now(timezone.utc).isoformat(),
    }

    paths = {
        "base_path": base_path,
        "parquet_filename": parquet_filename,
        "manifest_filename": manifest_filename,
    }

    logger.info("Built manifest for path: %s", base_path)
    return paths, manifest
