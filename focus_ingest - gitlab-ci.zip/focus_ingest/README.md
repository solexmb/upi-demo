# FOCUS Ingest Transform

Replaces the manual laptop step (download CSV -> run Python script -> upload)
with an Azure Function that fires automatically whenever the native Azure
Cost Management Export drops a new FOCUS CSV into the source storage
container.

## Structure

```
focus_ingest/
  focus_transform/       # the actual logic - pure, unit-tested, no Azure-specific glue
    config.py             # settings, loaded from environment variables
    schema.py              # FOCUS column validation (logs warnings, non-fatal)
    transform.py            # load CSV, clean BillingAccountId, convert to Parquet
    manifest.py              # report-period + manifest.json generation
    storage.py                # blob upload/download via Managed Identity
    cli.py                     # run it locally without deploying anything
  function_app.py         # thin Azure Function wrapper around focus_transform
  tests/
    test_transform.py     # unit tests - no Azure connection required
  requirements.txt
  host.json
```

The split matters: `focus_transform/` has no dependency on the Azure
Functions runtime, so you can run and test the real transformation logic
on your laptop with a sample CSV before it ever touches a live pipeline.
`function_app.py` is deliberately thin - it just wires the blob trigger to
that logic and controls what makes an invocation count as "failed" for
alerting purposes.

## Before deploying

1. **Confirm the manifest schema.** `build_manifest()` in `manifest.py` is
   a best-effort structure based on the folder-naming spec
   (`<Root>/<Optional_Sub_Dirs>/<Vendor>/<Report_Period>/<Epoch>`), not a
   confirmed field-by-field schema. Get a sample manifest from IBM support
   or Cloudability's docs and compare before relying on this in production.

2. **Confirm the core FOCUS column list.** `schema.py` checks a small set
   of columns that are Mandatory across FOCUS spec versions. Compare
   `CORE_FOCUS_COLUMNS` against the actual headers in your Cost Management
   Export CSV and adjust if needed - missing columns only log a warning,
   they don't block the pipeline, but you want to know if they're missing.

3. **Set the source blob trigger path** in `function_app.py`
   (`path="cost-exports/{name}"`) to match your actual export container.

## Local testing (no Azure required for a dry run)

```bash
pip install -r requirements.txt --break-system-packages
pytest tests/

# Dry run: transform a sample CSV, write Parquet + manifest to disk, no upload
python -m focus_transform.cli --input sample_focus_export.csv --output-dir ./out
```

## Testing against the real destination container

```bash
export FOCUS_DEST_ACCOUNT_URL="https://<destination-account>.blob.core.windows.net"
export FOCUS_DEST_CONTAINER="<root-directory-container-name>"
export FOCUS_VENDOR="Azure"
# export FOCUS_SUB_DIRECTORIES="finance/costs"   # only if your setup uses one

az login   # DefaultAzureCredential picks this up locally
python -m focus_transform.cli --input sample_focus_export.csv --upload
```

## Azure resources to create

- **Function App** (Python 3.11, Consumption or Premium plan)
- **System-assigned Managed Identity** on the Function App
- RBAC role assignments for that identity:
  - `Storage Blob Data Reader` on the **source** storage account
  - `Storage Blob Data Contributor` on the **destination** storage account
- App Settings on the Function App:
  - `SOURCE_STORAGE_CONNECTION` - identity-based connection to the source account
  - `FOCUS_DEST_ACCOUNT_URL`, `FOCUS_DEST_CONTAINER`, `FOCUS_VENDOR`,
    (optionally) `FOCUS_SUB_DIRECTORIES`
- **Application Insights** linked to the Function App, with an alert rule
  on function failures/exceptions so a broken run gets noticed immediately

## Deploy

```bash
az functionapp create \
  --resource-group <rg-name> \
  --consumption-plan-location <region> \
  --runtime python \
  --runtime-version 3.11 \
  --functions-version 4 \
  --name <function-app-name> \
  --storage-account <function-app-storage-account>

func azure functionapp publish <function-app-name>
```

## Alternative: running this as a scheduled GitLab CI pipeline instead

If you'd rather not run an Azure Function, `.gitlab-ci.yml` and
`focus_transform/pipeline.py` provide the same automation as a scheduled
GitLab pipeline instead - this finds the latest Cost Management Export
automatically and runs the same transform/upload logic.

**Required CI/CD variables** (Project > Settings > CI/CD > Variables, marked
**Protected** and **Masked**):
- `AZURE_CLIENT_ID`, `AZURE_TENANT_ID`, `AZURE_CLIENT_SECRET` - a service
  principal with `Storage Blob Data Reader` on the source container and
  `Storage Blob Data Contributor` on the destination container
- `SOURCE_ACCOUNT_URL`, `SOURCE_CONTAINER` - where the export lands
- `FOCUS_DEST_ACCOUNT_URL`, `FOCUS_DEST_CONTAINER` - where Cloudability reads from
- `FOCUS_VENDOR`, `FOCUS_REPORT_PREFIX` - must match Cloudability's credential config exactly

**Set up the daily schedule:** Project > Build > Pipeline schedules > New
schedule. Use cron syntax (e.g. `0 6 * * *` for 6am daily), pick your
timezone and target branch.

**Trigger it manually, any time, without waiting for the schedule** - two ways:
1. **From the GitLab UI:** Project > Build > Pipelines > **Run pipeline**,
   select the branch, and run. (This works because the job's `rules` allow
   `$CI_PIPELINE_SOURCE == "web"`, which is what a UI-triggered run reports.)
2. **From the API/command line**, using a trigger token (Project > Settings
   > CI/CD > Pipeline trigger tokens > create one):
   ```bash
   curl -X POST \
     -F token=<your-trigger-token> \
     -F ref=main \
     https://gitlab.example.com/api/v4/projects/<project-id>/trigger/pipeline
   ```
   Useful if you ever want to kick this off from another script or tool,
   not just by hand in the browser.

Either manual trigger runs the exact same job as the schedule does - there's
no separate "manual mode" to configure, it's the same `focus_ingest_daily`
job either way.
