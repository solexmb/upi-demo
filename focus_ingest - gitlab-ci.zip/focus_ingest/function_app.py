"""
Azure Function (Blob Trigger). Fires when Azure's native Cost Management
Export drops a new FOCUS CSV into the source container.

All actual logic lives in focus_transform/ and is unit-tested there - this
file just wires the trigger to it, and controls what makes the invocation
fail (so Application Insights sees it and can alert on it).
"""

import logging

import azure.functions as func

from focus_transform.config import Settings
from focus_transform.manifest import build_manifest, derive_report_period
from focus_transform.schema import validate_focus_columns
from focus_transform.storage import upload_outputs
from focus_transform.transform import clean_billing_account_id, csv_to_parquet, load_focus_csv

app = func.FunctionApp()


@app.function_name(name="FocusIngestTransform")
@app.blob_trigger(
    arg_name="myblob",
    path="cost-exports/{name}",              # source container + path pattern to watch
    connection="SOURCE_STORAGE_CONNECTION",  # App Setting: identity-based connection
)
def main(myblob: func.InputStream) -> None:
    logging.info("Triggered by new blob: %s (%s bytes)", myblob.name, myblob.length)

    try:
        settings = Settings.from_env()

        df = load_focus_csv(myblob.read())
        validate_focus_columns(df)  # logs a warning if columns are missing, doesn't block
        df = clean_billing_account_id(df)
        parquet_bytes = csv_to_parquet(df)

        report_period = derive_report_period(df)
        paths, manifest = build_manifest(
            report_period,
            vendor=settings.vendor,
            root_dir=settings.dest_container,
            optional_sub_directories=settings.optional_sub_directories,
            report_prefix=settings.report_prefix,
            focus_version=settings.focus_version,
        )
        upload_outputs(
            settings.dest_account_url,
            settings.dest_container,
            parquet_bytes,
            manifest,
            paths,
        )

        logging.info("Upload complete: %s/%s", settings.dest_container, paths["base_path"])
    except Exception:
        # Re-raise so the Function runtime marks this invocation as failed -
        # that's what surfaces in Application Insights and triggers alerts.
        logging.exception("FOCUS ingest transform failed for blob: %s", myblob.name)
        raise
